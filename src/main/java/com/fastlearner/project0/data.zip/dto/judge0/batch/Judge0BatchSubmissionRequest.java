package com.fastlearner.project0.dto.judge0.batch;

import com.fastlearner.project0.dto.judge0.Judge0SubmissionRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Judge0BatchSubmissionRequest
{
    private List<Judge0SubmissionRequest> submissions;
}
