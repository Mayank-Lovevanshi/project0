package com.fastlearner.project0.dto.judge0.batch;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Judge0BatchSubmissionResponse
{
    List<String> tokens;
}
