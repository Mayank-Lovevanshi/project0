package com.fastlearner.project0.serviceImpl;

import com.fastlearner.project0.dto.evaluation.EvaluationResult;
import com.fastlearner.project0.dto.judge0.Judge0SubmissionRequest;
import com.fastlearner.project0.dto.judge0.batch.Judge0BatchSubmissionRequest;
import com.fastlearner.project0.entity.Submission;
import com.fastlearner.project0.enums.SubmissionStatus;
import com.fastlearner.project0.enums.Verdict;
import com.fastlearner.project0.exceptions.ResourceNotFoundException;
import com.fastlearner.project0.repository.SubmissionRepository;
import com.fastlearner.project0.service.SubmissionEvaluatorService;
import com.fastlearner.project0.service.SubmissionProcessingService;
import org.modelmapper.ModelMapper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class SubmissionProcessingServiceImpl implements SubmissionProcessingService {
    private final SubmissionEvaluatorService submissionEvaluatorService;
    private final SubmissionRepository submissionRepository;

    public SubmissionProcessingServiceImpl(SubmissionEvaluatorService submissionEvaluatorService, SubmissionRepository submissionRepository, ModelMapper modelMapper) {
        this.submissionEvaluatorService = submissionEvaluatorService;
        this.submissionRepository = submissionRepository;
    }
    private void applyResult(EvaluationResult result, Submission submission)
    {
        submission.setVerdict(result.getVerdict());
        submission.setPassedTestCases(result.getPassedTestCases());
        submission.setExecutionTimeMs(result.getExecutionTimeMs());
        submission.setMemoryUsedKb(result.getMemoryUsedKb());
        submission.setTotalTestCases(result.getTotalTestCases());
        submission.setErrorMessage(result.getErrorMessage());
    }
    @Override
    @Async
    public void processSubmission(Long submissionId) {
        Submission submission = submissionRepository.findById(submissionId).orElseThrow(()->new ResourceNotFoundException("SUBMISSION_NOT_FOUND"));
        submission.setStatus(SubmissionStatus.RUNNING);
        submissionRepository.save(submission);
        EvaluationResult evaluationResult;
        try
        {
            evaluationResult = submissionEvaluatorService.evaluate(submission.getProblem(),submission.getLanguage(),submission.getSourceCode());
            submission.setStatus(SubmissionStatus.COMPLETED);
            applyResult(evaluationResult,submission);
            submissionRepository.save(submission);
        }
        catch (Exception e)
        {
            submission.setStatus(SubmissionStatus.FAILED);
            submission.setVerdict(Verdict.SYSTEM_ERROR);
            submission.setErrorMessage(e.getMessage());
            submissionRepository.save(submission);
        }


    }

    @Override
    @Async
    public void processBatchSubmissions(List<Long> submissionIds) {
        List<Submission> submissions = submissionRepository.findAllById(submissionIds);
        for (Submission submission : submissions)
        {
            submission.setStatus(SubmissionStatus.RUNNING);
            submission.setStartedAt(LocalDateTime.now());
            submissionRepository.save(submission);
        }
        submissionEvaluatorService.evaluateBatch(submissions);
        /*
        List<EvaluationResult> evaluationResults =  new ArrayList<>();
        try
        {
            evaluationResults = submissionEvaluatorService.evaluateBatch(submissions);
            for(int i=0;i<evaluationResults.size();i++)
            {
                submissions.get(i).setStatus(SubmissionStatus.COMPLETED);
                submissions.get(i).setCompletedAt(LocalDateTime.now());
                applyResult(evaluationResults.get(i),submissions.get(i));
                submissionRepository.save(submissions.get(i));
            }
        }
        catch (Exception e)
        {
            for(int i=0;i<evaluationResults.size();i++)
            {
                submissions.get(i).setStatus(SubmissionStatus.FAILED);
                submissions.get(i).setErrorMessage(e.getMessage());
                submissionRepository.save(submissions.get(i));
            }
        }

         */

    }
}
