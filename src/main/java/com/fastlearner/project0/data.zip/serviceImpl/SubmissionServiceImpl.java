package com.fastlearner.project0.serviceImpl;

import com.fastlearner.project0.dto.evaluation.EvaluationResult;
import com.fastlearner.project0.dto.judge0.JudgeResult;
import com.fastlearner.project0.dto.submission.CreateSubmissionRequest;
import com.fastlearner.project0.dto.submission.SubmissionResponse;
import com.fastlearner.project0.entity.*;
import com.fastlearner.project0.enums.Verdict;
import com.fastlearner.project0.exceptions.AuthenticationException;
import com.fastlearner.project0.exceptions.ResourceNotFoundException;
import com.fastlearner.project0.repository.*;
import com.fastlearner.project0.service.JudgeService;
import com.fastlearner.project0.service.SubmissionEvaluator;
import com.fastlearner.project0.service.SubmissionService;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
@Service
public class SubmissionServiceImpl implements SubmissionService {
    private final SubmissionRepository submissionRepository;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private final ProblemRepository problemRepository;
    private final SubmissionEvaluator submissionEvaluator;
    public SubmissionServiceImpl(SubmissionRepository submissionRepository, ModelMapper modelMapper, UserRepository userRepository, ProblemRepository problemRepository,SubmissionEvaluator submissionEvaluator) {
        this.submissionRepository = submissionRepository;
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
        this.problemRepository = problemRepository;
        this.submissionEvaluator = submissionEvaluator;
    }

    private Submission markSubmissionBeforeJudge(User user,Problem problem,CreateSubmissionRequest request)
    {
        Submission submission = new Submission();
        submission.setUser(user);
        submission.setProblem(problem);
        submission.setLanguage(request.getLanguage());
        submission.setSourceCode(request.getSourceCode());
        submission.setVerdict(Verdict.PENDING);
        submission.setSubmittedAt(LocalDateTime.now());
        return submissionRepository.save(submission);
    }
    private void applyResult(EvaluationResult result, Submission submission)
    {
        submission.setSubmittedAt(LocalDateTime.now());
        submission.setVerdict(result.getVerdict());
        submission.setPassedTestCases(result.getPassedTestCases());
        submission.setExecutionTimeMs(result.getExecutionTimeMs());
        submission.setMemoryUsedKb(result.getMemoryUsedKb());
        submission.setTotalTestCases(result.getTotalTestCases());
        submission.setErrorMessage(result.getErrorMessage());
        submissionRepository.save(submission);
    }
    @Override
    public SubmissionResponse submit(CreateSubmissionRequest request)
    {
        Long problemId = request.getProblemId();
        if(problemId == null || problemId <= 0) throw new IllegalArgumentException("INVALID_PROBLEM_ID");
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if(authentication == null) throw new AuthenticationException("AUTHENTICATION_NEEDED");

        String email = authentication.getName();
        User user = userRepository.findByEmail(email).orElseThrow(() -> new ResourceNotFoundException("USER_NOT_FOUND"));
        Problem problem = problemRepository.findById(problemId).orElseThrow(() -> new ResourceNotFoundException("PROBLEM_NOT_FOUND"));
        Submission submission = markSubmissionBeforeJudge(user,problem,request);
        EvaluationResult result = submissionEvaluator.evaluate(problem,request.getLanguage(),request.getSourceCode());
        applyResult(result, submission);
        return modelMapper.map(submission,SubmissionResponse.class);
    }

    @Override
    public SubmissionResponse getSubmissionById(Long id) {
        return null;
    }

    @Override
    public List<SubmissionResponse> getSubmissionsByProblemId(Long problemId) {
        return null;
    }

    @Override
    public List<SubmissionResponse> getMySubmissions() {
        return null;
    }
}
