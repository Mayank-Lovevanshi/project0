package com.fastlearner.project0.serviceImpl;

import com.fastlearner.project0.dto.judge0.JudgeResult;
import com.fastlearner.project0.dto.submission.CreateSubmissionRequest;
import com.fastlearner.project0.dto.submission.SubmissionResponse;
import com.fastlearner.project0.entity.Problem;
import com.fastlearner.project0.entity.Submission;
import com.fastlearner.project0.entity.TestCase;
import com.fastlearner.project0.entity.User;
import com.fastlearner.project0.enums.Verdict;
import com.fastlearner.project0.exceptions.ResourceNotFoundException;
import com.fastlearner.project0.repository.ProblemRepository;
import com.fastlearner.project0.repository.SubmissionRepository;
import com.fastlearner.project0.repository.TestCaseRepository;
import com.fastlearner.project0.repository.UserRepository;
import com.fastlearner.project0.service.Judge0Service;
import com.fastlearner.project0.service.SubmissionService;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
@Service
public class SubmissionServiceImpl implements SubmissionService {
    private final SubmissionRepository submissionRepository;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private final ProblemRepository problemRepository;
    private final TestCaseRepository testCaseRepository;
    private final Judge0Service judge0Service;
    public SubmissionServiceImpl(SubmissionRepository submissionRepository, ModelMapper modelMapper, UserRepository userRepository, ProblemRepository problemRepository, TestCaseRepository testCaseRepository, Judge0Service judge0Service) {
        this.submissionRepository = submissionRepository;
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
        this.problemRepository = problemRepository;
        this.testCaseRepository = testCaseRepository;
        this.judge0Service = judge0Service;
    }
    @Override
    public SubmissionResponse submit(CreateSubmissionRequest createSubmissionRequest)
    {
        Long problemId = createSubmissionRequest.getProblemId();
        if(problemId == null || problemId <= 0)
        {
            throw new IllegalArgumentException("INVALID_PROBLEM_ID");
        }
        // Get authenticated user
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userRepository.findByEmail(email).orElseThrow(() -> new ResourceNotFoundException("USER_NOT_FOUND"));

        // Get problem
        Problem problem = problemRepository
                .findById(problemId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "PROBLEM_NOT_FOUND"));
        List<TestCase> testCases = testCaseRepository.findByProblemId(problemId).orElseThrow(()->new ResourceNotFoundException("TEST_CASE_NOT_FOUND"));


        // Create submission
        Submission submission = new Submission();

        submission.setUser(user);
        submission.setProblem(problem);
        submission.setLanguage(createSubmissionRequest.getLanguage());
        submission.setSourceCode(createSubmissionRequest.getSourceCode());
        submission.setVerdict(Verdict.PENDING);
        submission.setSubmittedAt(LocalDateTime.now());

        submission = submissionRepository.save(submission);

        int passed = 0;
        Long maxExecutionTime = 0L;
        Long maxMemoryUsed = 0L;
        for(TestCase testCase : testCases)
        {
            JudgeResult judgeResult =
                    judge0Service.execute(
                            createSubmissionRequest.getSourceCode(),
                            createSubmissionRequest.getLanguage(),
                            testCase.getInputData()
                    );

            // Track max execution time
            if(judgeResult.getExecutionTimeMs() != null)
            {
                maxExecutionTime = Math.max(
                        maxExecutionTime,
                        judgeResult.getExecutionTimeMs()
                );
            }

            // Track max memory usage
            if(judgeResult.getMemoryUsedKb() != null)
            {
                maxMemoryUsed = Math.max(
                        maxMemoryUsed,
                        judgeResult.getMemoryUsedKb()
                );
            }
            // Compilation Error
            if(judgeResult.getVerdict()
                    == Verdict.COMPILATION_ERROR)
            {
                submission.setVerdict(Verdict.COMPILATION_ERROR);
                break;
            }

            // Runtime Error
            if(judgeResult.getVerdict() == Verdict.RUNTIME_ERROR)
            {
                submission.setVerdict(Verdict.RUNTIME_ERROR);
                break;
            }

            // Time Limit Exceeded
            if(judgeResult.getVerdict() == Verdict.TIME_LIMIT_EXCEEDED)
            {
                submission.setVerdict(Verdict.TIME_LIMIT_EXCEEDED);
                break;
            }

            String actualOutput = judgeResult.getOutput() == null
                            ? ""
                            : judgeResult.getOutput().trim();

            String expectedOutput = testCase.getExpectedOutput().trim();

            if(!actualOutput.equals(expectedOutput))
            {
                submission.setVerdict(Verdict.WRONG_ANSWER);
                break;
            }
            passed++;
        }
        if(passed == testCases.size())
        {
            submission.setVerdict(Verdict.ACCEPTED);
        }

        submission.setPassedTestCases(passed);
        submission.setTotalTestCases(testCases.size());
        submission.setExecutionTimeMs(maxExecutionTime);

        submission.setMemoryUserKb(maxMemoryUsed);

        Submission savedSubmission = submissionRepository.save(submission);

        return modelMapper.map(savedSubmission,SubmissionResponse.class);
    }

    @Override
    public SubmissionResponse getSubmissionById(Long id) {
        return null;
    }

    @Override
    public List<SubmissionResponse> getSubmissionsByProblemId(Long problemId) {
        return null;
    }

    @Override
    public List<SubmissionResponse> getMySubmissions() {
        return null;
    }
}
