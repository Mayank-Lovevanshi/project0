package com.fastlearner.project0;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class Project0Application {

	public static void main(String[] args) {
		SpringApplication.run(Project0Application.class, args);
	}

}


